package Actividad_1;

public class Main {

	public static void main(String[] args) {
		Factoriales a = new Factoriales();
		a.buildArray();
		a.seeArray();
		a.Imprimir();

	}

}
